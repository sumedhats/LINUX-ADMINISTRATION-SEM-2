#include <stdio.h>
int main()
{
int (a,b,c);
printf("Enter the value a,b numbers");
scanf("%d,%d"&a,%b);
c=(a-b);
printf("The Subtaction of 2 numbers is:%d",c);
return 0;
}

